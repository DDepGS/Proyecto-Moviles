
actionRead();

function actionRead(){
  $( document ).ready(function() {

      $.ajax({
      url: "php/organizar_notificaciones.php",
      success: function( result ) {
        var respuesta=JSON.parse(result);
        if(respuesta.estatus==1){
          respuesta.aquellos.forEach(function(pac){
            item= "<tr role='row' class='even'><td class='dtr-control sorting_1' tabindex='"+pac.numero+"'>"+pac.asunto+"</td><td>"+pac.grupo+"</td><td><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#modal-default"+pac.numero+"'>Ver</button><div class='modal fade' id='modal-default"+pac.numero+"' style='text-align:right'><div class='modal-dialog'><div class='modal-content'><div class='modal-header'><h4 class='modal-title'>Notificación</h4><button type='button' class='close' data-dismiss='modal' aria-label='Close'> <span aria-hidden='true'>&times;</span></button> </div><div class='modal-body'><p><b>Asunto:</b> "+pac.asunto+"</p><p><b>Destinatarios:</b> Academia de Sistemas</p><p><b>Descripción:</b></p><p>"+pac.descripcion+"</p> <p><b>Fecha:</b> "+pac.fecha+"</p></div><div class='modal-footer'><button type='button' class='btn btn-primary' data-dismiss='modal'>Cerrar</button></div></div><!-- /.modal-content --></div><!-- /.modal-dialog --></div> </td></tr>";
            $('#notificar').append(item);
          });
        }
      }
    });

  });
}
