<?php
    $titulo= $_POST['asunto'];
    $descripcion= $_POST['descripcion'];
    $fecha= date('Y-m-d H:i:s');
    $grupo= $_POST['grupo'];

    $servidor = "localhost";
	$usuario  = "root";
	$clave    = "";
	$base     = "moviles";

	$conexion = mysqli_connect($servidor,$usuario,$clave,$base);

    if($conexion){
            $query="INSERT INTO `notificacion` (`idNotificacion`, `titulo`, `descripcion`, `fecha`, `Grupo_idGrupo`) VALUES (NULL, '$titulo', '$descripcion', '$fecha', '$grupo');";
            mysqli_query($conexion,$query);
            $id = mysqli_insert_id($conexion);
            if(mysqli_affected_rows($conexion)>0){
                echo'<script type="text/javascript">
                 alert("Se guardó correctamente la informacion");
                window.location.href="/Web/AdminLTE-3.1.0-rc/pages/tables/notificaciones.html"; 
                </script>';
            }else{
                echo'<script type="text/javascript">
                 alert("no se guardó '.$fecha.$titulo.$descripcion.$grupo.' ");
                window.location.href="/Web/AdminLTE-3.1.0-rc/pages/tables/notificaciones.html";
                </script>';
                exit();
            }
    }else{
        echo'<script type="text/javascript">
        alert("no entré a la base");
       window.location.href="/Web/AdminLTE-3.1.0-rc/pages/tables/notificaciones.html";
       </script>';;
        exit();
    }
?>