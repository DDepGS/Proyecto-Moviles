<?php
    $seleccion=$_POST["nombre"];
    
    $co=mysqli_connect('localhost','root','') or die('NO');
    $db=mysqli_select_db($co,"moviles") or die('no bd');

    $cons="DELETE from grupo where idGrupo='" . $seleccion . "'";;
	$result= mysqli_query($co,$cons) or die('No consulta');
    
    header("Location: agrupamiento.php");
    exit();
?>