package com.example.proyecto.ui.Carpeta_Notificaciones;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class NotificacionesModel extends ViewModel {

    private MutableLiveData<String> mText;

    public NotificacionesModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Listado de Notificaciones");
    }

    public LiveData<String> getText() {
        return mText;
    }
}