package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {
    Button continuar;
    EditText comprobacion;
    Spinner seleccion;
    String tipo,concatenar; //Seleccion si es alumno o docente;
    //Datos de los alumno
    String nombre_A,programa_A,estado_A;
    String encontrado_A="";//Si enceuntra el alumno o no
    //Datos del docente

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String [] opciones={"Alumno","Docente"};
        setContentView(R.layout.activity_login);
        continuar=findViewById(R.id.btn_continuar);
        comprobacion=findViewById(R.id.edt_bole_trab);
        seleccion=findViewById(R.id.sp_alu_docen);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,opciones);
        seleccion.setAdapter(adapter);

        //Recuperar preferencias
        recuperarPreferencias();

        continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipo=seleccion.getSelectedItem().toString();
                 if(tipo == "Alumno"){
                      String boleta = comprobacion.getText().toString();
                      concatenar="http://sistemas.upiiz.ipn.mx/isc/nopu/api/alumno.php?boleta="+ boleta;
                      ejecutarServicioAlumno(concatenar, boleta, tipo);
                 }else if(tipo =="Docente") {
                     String numEmpleado = comprobacion.getText().toString();
                     concatenar="http://sistemas.upiiz.ipn.mx/isc/nopu/api/personal.php?numempleado="+ numEmpleado;
                     ejecutarServicioDocente(concatenar, numEmpleado, tipo);
                 }else{
                     Toast.makeText(getApplicationContext(), "Alguien no hizo bien su tarea no deberia pasar esto", Toast.LENGTH_SHORT).show();
                 }
            }
        });


    }

    public void  ejecutarServicioDocente(String URL, final String numEmpleado, final String barras){
        StringRequest request=new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    estado_A=jsonObject.getString("estado");
                    encontrado_A = jsonObject.getString("mensaje");
                    if(estado_A.equals("1") && encontrado_A.equals("Empleado encontrado")){
                        nombre_A= jsonObject.getString("nombre");
                        programa_A=jsonObject.getString("programa");

                        guardarPreferencias(numEmpleado, barras, nombre_A, programa_A);

                        guardarEnBD();

                        startActivity(new Intent(getApplicationContext(), MenuPrincipal.class));
                        //Toast.makeText(getApplicationContext(), "Alumno: "+nombre_A+"programa: "+programa_A+"estado: "+estado_A+"mensaje: "+encontrado_A, Toast.LENGTH_SHORT).show();
                        Toast.makeText(getApplicationContext(), "Ingreso correcto", Toast.LENGTH_SHORT).show();

                    }else{
                        Toast.makeText(getApplicationContext(), "Usuario Incorrecto", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Login.this,error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    public void ejecutarServicioAlumno(String URL, final String boleta, final String barra){
        StringRequest request=new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    estado_A=jsonObject.getString("estado");
                    encontrado_A = jsonObject.getString("mensaje");
                    if(estado_A.equals("1") && encontrado_A.equals("Alumno encontrado")){
                        nombre_A= jsonObject.getString("nombre");
                        programa_A=jsonObject.getString("programa");

                        guardarPreferencias(boleta, barra, nombre_A, programa_A);

                        guardarEnBD();

                        startActivity(new Intent(getApplicationContext(), MenuPrincipal.class));
                        Toast.makeText(getApplicationContext(), "Ingreso correcto", Toast.LENGTH_SHORT).show();
                        //------------------------------------------------
                   }else{
                        Toast.makeText(getApplicationContext(), "Usuario Incorrecto", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Login.this,error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void guardarEnBD(){
        SharedPreferences preferences = getSharedPreferences("sesion", Context.MODE_PRIVATE);
        final String nombreStr = preferences.getString("nombre", "");
        final String boletStr = preferences.getString("boleta","");
        final String tipoStr = preferences.getString("barra","");
        final String programaStr = preferences.getString("program","");
        SharedPreferences tokens = getSharedPreferences("tokenG", Context.MODE_PRIVATE);
        final String tokenStr = tokens.getString("token","");


        Toast.makeText(getApplicationContext(), "llegue", Toast.LENGTH_SHORT).show();
        //Toast.makeText(getApplicationContext(), "tipo: "+ tipoStr+" programa: "+programaStr, Toast.LENGTH_LONG).show();

        //Toast.makeText(getApplicationContext(), "token: "+ tokenStr, Toast.LENGTH_SHORT).show();

        String URL = "http://localhost/api/insertar.php";
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Por favor espere...");
        progressDialog.show();
        StringRequest request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                //progressDialog.dismiss();
                comprobacion.setText("");
                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT);
            }
        }
        ){

            protected Map<String, String> getParams() throws AuthFailureError{
                Map<String, String> params = new HashMap<String, String>();
                params.put("nombrecompleto", nombreStr);
                params.put("boleta", boletStr);
                params.put("token", tokenStr);
                params.put("tipo", tipoStr);
                params.put("Programa", programaStr);

                return params;
            }
        };
        Toast.makeText(getApplicationContext(), "termine", Toast.LENGTH_SHORT).show();
        RequestQueue requestQueue = Volley.newRequestQueue(Login.this);
        requestQueue.add(request);
    }

    private void guardarPreferencias(String boleta, String barra, String nombre, String program){
        //creacion del archivo sesion.xml, guardara nuestros datos
        SharedPreferences preferences = getSharedPreferences("sesion", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        //cargamos las credenciales
        editor.putString("boleta", boleta);
        editor.putString("nombre", nombre);
        editor.putString("barra", barra);
        editor.putString("program", program);
        editor.putBoolean("band", true);
        editor.commit();
    }

    private void recuperarPreferencias(){
        SharedPreferences preferences = getSharedPreferences("sesion", Context.MODE_PRIVATE);
        comprobacion.setText(preferences.getString("boleta", ""));
        //SharedPreferences tokens = getSharedPreferences("tokenG", Context.MODE_PRIVATE);
        //Toast.makeText(getApplicationContext(),"mi token: "+tokens.getString("token", ""), Toast.LENGTH_SHORT).show();
    }
}