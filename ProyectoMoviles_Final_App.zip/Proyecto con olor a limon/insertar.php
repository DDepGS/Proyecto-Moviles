<?php
   $servidor = "localhost";
   $usuario  = "root";
   $clave    = "";
   $base     = "moviles";

   $conexion = mysqli_connect($servidor, $usuario, $clave, $base);    
   
    $nombre = $_POST["nombre"];
    $boleta = $_POST["boleta"];
    $token = $_POST["token"];
    $tipo = $_POST["tipo"];
    $programa = $_POST["programa"];

    $sql = "INSERT INTO usuarios(nombrecompleto,boleta,token,tipo,Programa) VALUES ('$nombre','$boleta','$token','$tipo','$programa')";
    $result = mysqli_query($conexion, $sql);

    if($result){
        echo "Datos insertados";
    }else{
        echo "No se insertaron los datos";
    }
?>