<?php 


	$co=mysqli_connect('127.0.0.1','root','') or die('NO');
	$db=mysqli_select_db($co,"moviles") or die('no bd');

 ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Grupos</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <!--<li class="nav-item d-none d-sm-inline-block">
        <a href="../../index3.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li> -->
    </ul>

    <!-- SEARCH FORM -->
    <!--<form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Buscar" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form> -->

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      <!-- Notifications Dropdown Menu -->
      
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="../../index.html" class="brand-link">
      <img src="../../dist/img/AdminLTELogo.png"
           alt="AdminLTE Logo"
           class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">UPIIZ IPN</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
         
          <li class="nav-item">
            <li class="nav-item">
              <!--<i class="nav-icon fas fa-tree"></i>-->
                <a href="../tables/notificaciones.html" class="nav-link">
                    <p> Notificaciones</p>
                </a>
                <!-- <i class="fas fa-angle-left right"></i> -->
            </li>
            <li class="nav-item">
                <!--<i class="nav-icon fas fa-tree"></i>-->
                  <a href="../tables/agrupamiento.php" class="nav-link">
                      <p> Agrupamientos</p>
                  </a>
                  <!-- <i class="fas fa-angle-left right"></i> -->
                </li>
              <li class="nav-item">
                <!--<i class="nav-icon fas fa-tree"></i>-->
                  <a href="#" class="nav-link">
                      <p> Salir</p>
                  </a>
                  <!-- <i class="fas fa-angle-left right"></i> -->
             </li>
          </li>

        
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Grupos</h1>
          </div>
          <div class="col-sm-6">
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
           
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <!-- <h3 class="card-title">Enviar notificación</h3> -->
              </div>
              
              <!-- /.card-header -->
              <div class="card-body" style="text-align:right" >
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default">
                            Nueva
                          </button>
                          <div class="modal fade" id="modal-default">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h4 class="modal-title">Nuevo grupo</h4>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                <form method="POST" action="nuevo_grupo.php">
                                    <div class="form-group" style="text-align:justify">
                                        <label for="exampleInputEmail1">Nombre</label>
                                        <input type="text" name="nombre" class="form-control" id="exampleInputEmail1" placeholder="Ingrese nombre">
                                      </div>
                                      <div class="form-group" style="text-align:justify">
                                        <label>Descripción</label>
                                        <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese una descripción"></textarea>
                                      </div>
                                      <!-- <div class="form-group">
                                        <label>Seleccione un grupo</label>
                                        <select class="custom-select">
                                          <option>Becas</option>
                                          <option>BEIFI</option>
                                          <option>Credenciales</option>
                                          <option>Delfin</option>
                                        </select>
                                      </div> -->
                                </div>
                                <div class="modal-footer justify-content-between">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-primary" >Enviar</button>
                                </div>
                                </form>
                              </div>
                              <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                          </div>
                    </li>
                  </ul>
                  <br />
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Acción</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php 
                      $consulta="SELECT * from programa";
                      $result= mysqli_query($co,$consulta) or die('No consulta');
                      $consult="SELECT * from agrupamiento";
                      $resul= mysqli_query($co,$consult) or die('No consulta');
                      $consul="SELECT * from grupo";
                      $resu= mysqli_query($co,$consul) or die('No consulta');
                      $cons="SELECT * from grupo";
                      $re= mysqli_query($co,$consul) or die('No consulta');
                      $uconsulta="SELECT * from usuario";
                      $resultado= mysqli_query($co,$uconsulta) or die('No consulta');
                      

                      while($mostrar=mysqli_fetch_array($resu))
                      {
                        echo'<tr>';
                        echo'<td>'.$mostrar['nombre'].'</td>';
                        echo'<td>'.$mostrar['descripcion'].'</td>'; 
                        $nom=$mostrar['idGrupo'];
                        $consu="SELECT * from usuario where idUsuario='" . $nom . "'";
                        $res= mysqli_query($co,$consu) or die('No consulta');
                        echo'<td>
                        <button type="button" class="btn btn-app"  data-toggle="modal" data-target="#modal-default-u">
                        <i class="fas fa-users"></i>
                        </button>
                        <button type="button" class="btn btn-app" data-toggle="modal" data-target="#modal-default-e-'.$nom.'">
                          <i class="fas fa-edit"></i>
                          </button>
                          <button type="button" class="btn btn-app" data-toggle="modal" data-target="#modal-default'.$nom.'">
                            <i class="fas fa-edit"></i>
                            </button>

                            <div class="modal fade" id="modal-default'.$nom.'">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h4 class="modal-title">Eliminar Proyecto</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body" style="text-align: justify;">
                                  <form action="eagrupamiento.php" method="POST">
                                    <p>¿Está seguro que desea eliminar el Proyecto?</p>
                                    <input  type="hidden" name="nombre" value="'.$mostrar['idGrupo'].'">
                                  </div>
                                  <div class="modal-footer justify-content-between">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                  </div>
                                  </form>
                                </div>
                                <!-- /.modal-content -->
                              </div>
                              <!-- /.modal-dialog -->
                            </div>
                            <!-- /.modal -->
                        <div class="modal fade" id="modal-default-u">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Asignar grupo</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body" style="text-align:justify">
                              <form action="agrupar.php" method="POST">
                                <table id="example1" class="table table-bordered table-striped">
                                  <thead>
                                  <tr>
                                    <th>Nombre</th>
                                    <th>Función</th>
                                    <th>Acción</th>
                                  </tr>
                                  </thead>
                                  <tbody>';
                                  
                                  while($um=mysqli_fetch_array($resultado))
                                  {
                                    echo'<tr>';
                                    echo'<td>'.$um['nombrecompleto'].'</td>';
                                    echo'<td>'.$um['tipo'].'</td>
                                    <td>
                                      <a href="#" class="nav-link">
                                        <p>E</p>
                                    </a>
                                    </td>
                                  </tr>';
                                  }
                                  
                                
                                  echo'</tbody>
                                  <tfoot>
                                  <tr>
                                    <!-- <th>Asunto</th>
                                    <th>Grupo</th>
                                    <th>Acción</th> -->
                                    
                                  </tr>
                                  </tfoot>
                                </table>
                                <div style="text-align:right">
                                  <div class="form-group" style="text-align:justify">
                                    <label >Grupo</label>
                                    <select name="grupo" class="form-control">
                                      <option value=" 1">Seleccione un grupo</option>';
                                      while($gm=mysqli_fetch_array($re))
                                      {
                                        echo '<option name="grupo" value="'.$gm['idGrupo'].'">'.$gm['nombre'].'</option>';
                                      }
                                    echo'</select>
                                  </div>
                                  <button type="button" class="btn btn-primary" data-dismiss="#">Asignar</button>
                                </div>
                                <div>
                                  <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                      <th>Nombre</th>
                                      <th>Función</th>
                                      <th>Acción</th>
                                    </tr>
                                    </thead>
                                    <tbody>';
                                    while($mostra=mysqli_fetch_array($res))
                                    {
                                      echo'<tr>';
                                      echo'<td>'.$mostra['nombrecompleto'].'</td>';
                                      echo'<td>'.$mostra['tipo'].'</td>
                                      <td>
                                        <a href="#" class="nav-link">
                                          <p>E</p>
                                      </a>
                                      </td>
                                    </tr>';
                                    }
                                    
                                    echo'</tbody>
                                    <tfoot>
                                    <tr>
                                      <!-- <th>Asunto</th>
                                      <th>Grupo</th>
                                      <th>Acción</th> -->
                                      
                                    </tr>
                                    </tfoot>
                                  </table>
                                  </div>
                              </div>
                              
                              <div class="modal-footer" style="text-align:right">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
                              </div>
                              </form>
                            </div>
                            <!-- /.modal-content -->
                          </div>
                        </div>
                          
                        <div class="modal fade" id="modal-default-e-'.$nom.'">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h4 class="modal-title">Editar grupo</h4>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                <form method="POST" action="editar_grupo.php">
                                    <div class="form-group" style="text-align:justify">
                                        <label for="exampleInputEmail1">Nombre</label>
                                        <input type="text" name="nombre" class="form-control" id="exampleInputEmail1" placeholder="Ingrese nombre">
                                      </div>
                                      <div class="form-group" style="text-align:justify">
                                        <label>Descripción</label>
                                        <textarea class="form-control" name="descripcion" rows="3" placeholder="Ingrese una descripción"></textarea>
                                      </div>
                                      <!-- <div class="form-group">
                                        <label>Seleccione un grupo</label>
                                        <select class="custom-select">
                                          <option>Becas</option>
                                          <option>BEIFI</option>
                                          <option>Credenciales</option>
                                          <option>Delfin</option>
                                        </select>
                                      </div> -->
                                      <input type="hidden" name="grupo" value="'.$nom.'">
                                </div>
                                <div class="modal-footer justify-content-between">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                                  <button type="submit" class="btn btn-primary" >Enviar</button>
                                </div>
                                </form>
                              </div>
                              <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                          </div>
                           
                          </td>';
                        echo'</tr>';
                      }
                    ?>
              
                
                  </tbody>
                  <tfoot>
                  <tr>
                    <!-- <th>Asunto</th>
                    <th>Grupo</th>
                    <th>Acción</th> -->
                    
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.5
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
</body>
</html>