<?php
    $persona=$_POST["nombre"];
    $grupo=$_POST["grupo"];
    
    $co=mysqli_connect('localhost','root','') or die('NO');
    $db=mysqli_select_db($co,"moviles") or die('no bd');

    $cons="INSERT into agrupamiento (`idAgrupamiento`, `Usuario_idUsuario`, `Grupo_idGrupo`) VALUES (NULL,'".$persona."','".$grupo."')";;
	$result= mysqli_query($co,$cons) or die('No consulta');
    
    header("Location: agrupamiento.php");
    exit();
?>