<?php        
    $respuesta = array();

    $servidor = "localhost";
	$usuario  = "root";
	$clave    = "";
	$base     = "moviles";

	$conexion = mysqli_connect($servidor,$usuario,$clave,$base);

    $numero = 1;
    if($conexion){
        //Consulta para mostrar todos los registros de la tabla materia
        $query="SELECT * FROM `notificacion`";
    
        $respuesta['aquellos']=array();

        $registros = mysqli_query($conexion,$query);
        while($notificacion=mysqli_fetch_array($registros)){
            $pac = array();
            $pac['numero']	=$numero;
            $pac['asunto']	=$notificacion['titulo'];
            $pac['descripcion']  =$notificacion['descripcion'];	
            if($notificacion['Grupo_idGrupo'] == 1){
                $pac['grupo'] = "Becas";
            } elseif($notificacion['Grupo_idGrupo'] == 2){
                $pac['grupo'] = "BEIFI";
            } elseif($notificacion['Grupo_idGrupo'] == 3){
                $pac['grupo'] = "Credenciales";
            } elseif($notificacion['Grupo_idGrupo'] == 4){
                $pac['grupo'] = "Delfin";
            }
            $pac['fecha']	=$notificacion['fecha'];
            
            $numero ++;

            array_push($respuesta['aquellos'], $pac); 
        }
        $respuesta['estatus']=1;
        $respuesta['mensaje']='Consulta Existosa';

    }else{
        $respuesta['estatus']=0;
        $respuesta['mensaje']="No se pudo conectar";
    }

    echo json_encode($respuesta);
?>