<?php
    $nombre= $_POST['nombre'];
    $descripcion= $_POST['descripcion'];

    $servidor = "localhost";
	$usuario  = "root";
	$clave    = "";
	$base     = "moviles";

	$conexion = mysqli_connect($servidor,$usuario,$clave,$base);

    if($conexion){
            $query="INSERT INTO `grupo` (`idGrupo` , `nombre`  , `descripcion`) VALUES (NULL, '$nombre', '$descripcion');";
            mysqli_query($conexion,$query);
            $id = mysqli_insert_id($conexion);
            if(mysqli_affected_rows($conexion)>0){
                echo'<script type="text/javascript">
                 alert("Se guardó correctamente la informacion");
                window.location.href="agrupamiento.php"; 
                </script>';
            }else{
                echo'<script type="text/javascript">
                 alert("no se guardó '.$fecha.$titulo.$descripcion.$grupo.' ");
                window.location.href="agrupamiento.php";
                </script>';
                exit();
            }
    }else{
        echo'<script type="text/javascript">
        alert("no entré a la base");
       window.location.href="agrupamiento.php";
       </script>';;
        exit();
    }
?>