function btnIngresar(){
    var usuario= document.getElementById('usuarioBox').value;
    var password=document.getElementById('passwordBox').value;
    if(usuario=='121179' && password=='121179'){
        //alert(usuario);
        //alert(password);
        //alert('bienvenido');
        window.location="../../index.html";
        
    }else{
        //alert(document.getElementById('usuarioBox'));
        //alert(document.getElementById('passwordBox'));  
        alert('Usuario o Clave incorrecta'); 
    }
}