<?php
	$conexion = new mysqli("localhost","root","","moviles");

?>